const mongoose = require('mongoose');

const fileTrackingSchema = new mongoose.Schema({
  originalFile: {
    type: String,
    required: true
  },
  completedFile: {
    type: String,
    default: null
  },
  requiredHour: {
    type: Number,
    min: [0, 'Required hours must be at least 0']
  },
  status: {
    type: String,
    enum: ['pending', 'in_progress', 'completed'],
    default: 'pending'
  },
  uploadedAt: {
    type: Date,
    default: Date.now
  },

  // 🔹 User Feedback Fields
  userReportedStatus: {
    type: String,
    enum: ['ok', 'reported'],
    default: 'ok'
  },
  userNotes: {
    type: String,
    maxlength: [1000, 'User notes cannot exceed 1000 characters']
  }
});

const quotationSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  payment: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Payment'
  },
  projectName: {
    type: String,
    required: [true, 'Please add a project name'],
    trim: true,
    maxlength: [100, 'Project name cannot be more than 100 characters']
  },
  description: {
    type: String,
    trim: true,
    maxlength: [500, 'Description cannot be more than 500 characters']
  },
  technicalInfo: String,
  resolution: String,
  deadline: Date,

  requiredHour: {
    type: Number,
    min: [0, 'Total required hours must be at least 0']
  },

  deliverables: {
    type: String,
    maxlength: [1000, 'Deliverables cannot be more than 1000 characters']
  },

  files: {
    type: [fileTrackingSchema],
    default: []
  },

  infoFiles: {
    type: [String],
    default: []
  },

  quotationFile: {
    type: String,
    default: null
  },
  completedQuotationFile: {
    type: String,
    default: null
  },
  
  status: {
    type: String,
    enum: ['requested', 'quoted', 'approved', 'rejected', 'ongoing', 'reported', 'completed'],
    default: 'requested'
  },
  poStatus: {
    type: String,
    enum: ['requested', 'approved', 'rejected']
  },
  rejectionReason: {
    type: String,
    enum: ['price', 'timeline', 'requirements', 'other', 'user_rejection']
  },
  rejectionDetails: {
    type: String,
    maxlength: [1000, 'Rejection details cannot exceed 1000 characters']
  },
  rejectedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  rejectedAt: Date,

  notes: {
    type: String,
    maxlength: [1000, 'Notes cannot be more than 1000 characters']
  },

  completedAt: Date,

  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

quotationSchema.pre('save', function (next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('Quotation', quotationSchema);
