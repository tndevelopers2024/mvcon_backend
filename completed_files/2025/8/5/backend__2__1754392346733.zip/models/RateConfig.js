const mongoose = require('mongoose');

const rateConfigSchema = new mongoose.Schema({
  ratePerHour: {
    type: Number,
    required: [true, 'Please add a rate per hour'],
    min: [0, 'Rate cannot be negative']
  },
  currency: {
    type: String,
    default: 'USD',
    trim: true,
    uppercase: true,
    enum: ['USD'], // Only USD allowed
    maxlength: [3, 'Currency code cannot be more than 3 characters']
  },
  country: {
    type: String,
    required: [true, 'Please specify country code'],
    trim: true,
    uppercase: true,
    maxlength: [2, 'Country code cannot be more than 2 characters'],
    match: [/^[A-Z]{2}$/, 'Please use a valid 2-letter country code (ISO 3166)']
  },
  effectiveFrom: {
    type: Date,
    default: Date.now
  },
  isActive: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Auto-update timestamp
rateConfigSchema.pre('save', function (next) {
  this.updatedAt = Date.now();
  next();
});

// Ensure only one active rate per country
rateConfigSchema.index({ country: 1, isActive: 1 }, { unique: true, partialFilterExpression: { isActive: true } });

module.exports = mongoose.model('RateConfig', rateConfigSchema);