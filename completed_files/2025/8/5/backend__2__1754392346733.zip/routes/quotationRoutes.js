const express = require('express');
const {
  getQuotations,
  getQuotation,
  requestQuotation,
  raiseQuote,
  userDecision,
  completeQuotation,
  updateQuotation,
  deleteQuotation,
  getUserQuotations,
  markQuotationOngoing,
  getUserQuotationsById,
  updatePoStatus,
  userDecisionPO,
  updateRequiredHourAgain,
  rejectWithMessage,
  deleteQuoteFile,
  reportQuotationIssues,
  uploadIssuedFiles
} = require('../controllers/quotationController');

const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// 🔹 Public or protected as needed
router.route('/')
  .get(getQuotations)
  .post(protect, requestQuotation);

router.get('/my-quotations', protect, getUserQuotations);

router.route('/user/:id')
  .get(protect, getUserQuotationsById);

router.route('/:id')
  .get(getQuotation)
  .put(protect, updateQuotation)
  .delete(deleteQuotation);

router.route('/:id/po-status')
  .put(protect, updatePoStatus);

router.route('/:id/files/:fileId')
  .delete(deleteQuoteFile);

// 🔹 Quotation Actions
router.put('/:id/update-hour', protect, authorize('admin'), updateRequiredHourAgain);
router.put('/:id/decision', protect, authorize('user', 'company'), userDecision);
router.put('/:id/decisionpo', protect, authorize('user', 'company'), userDecisionPO);
router.put('/:id/ongoing', protect, authorize('admin'), markQuotationOngoing);
router.put('/:id/complete', protect, authorize('admin'), completeQuotation);
router.put('/:id/reject-with-message', protect, rejectWithMessage);

// 🔹 🆕 Add user-side issue reporting and replacement file uploads
router.post('/:id/report-issues', protect, authorize('user', 'company'), reportQuotationIssues);
router.post('/:id/upload-issued-files', protect, uploadIssuedFiles);
router.post('/:id/quote', protect, authorize('admin'), raiseQuote);
module.exports = router;
