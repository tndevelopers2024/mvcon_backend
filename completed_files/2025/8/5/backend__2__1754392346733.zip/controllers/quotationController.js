const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../utils/asyncHandler');
const path = require('path');
const fs = require('fs');
const Quotation = require('../models/Quotation');
const User = require('../models/User');
const Notification = require('../models/Notification');
const sendEmail = require('../utils/sendEmail');
const { createAdminNotification } = require('../utils/notificationHelpers');

// Constants
const MAX_FILE_SIZE = 1 * 1024 * 1024 * 1024; // 1GB
// Removed ALLOWED_UPLOAD_EXTENSIONS to accept all file types
const VALID_PO_STATUSES = ['requested', 'approved', 'rejected', 'pending'];

// Helper function to load email template
const loadEmailTemplate = async (templateName, replacements) => {
  try {
    const templatePath = path.join(__dirname, `../emailTemplates/${templateName}`);
    let template = await fs.promises.readFile(templatePath, 'utf8');
    
    for (const [key, value] of Object.entries(replacements)) {
      template = template.replace(new RegExp(`{{${key}}}`, 'g'), value);
    }
    
    return template;
  } catch (err) {
    console.error(`Error loading email template ${templateName}:`, err);
    throw new Error('Failed to load email template');
  }
};

// Helper function to send email notifications
const sendQuotationEmail = async ({ email, subject, message, attachments = [] }) => {
  try {
    const message = await loadEmailTemplate(templateName, replacements,);
    await sendEmail({
      email,
      subject,
      message,
       attachments 
    });
  } catch (err) {
    console.error('Email sending failed:', err);
  }
};

// Helper function to validate and save file (modified to accept all file types)
const saveUploadedFile = async (file, basePath) => {
  const fileExtension = path.extname(file.name).toLowerCase();
  
  // Validate file size
  if (file.size > MAX_FILE_SIZE) {
    throw new ErrorResponse(`File exceeds ${MAX_FILE_SIZE / (1024 * 1024)}MB limit`, 400);
  }

  // Create upload directory structure
  const now = new Date();
  const uploadDir = path.join(
    __dirname, 
    basePath,
    `${now.getFullYear()}`,
    `${now.getMonth() + 1}`,
    `${now.getDate()}`
  );

  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
  }

  // Generate sanitized filename
  const originalName = path.parse(file.name).name;
  const sanitizedName = originalName.replace(/[^a-z0-9]/gi, '_').toLowerCase();
  const fileName = `${sanitizedName}_${Date.now()}${fileExtension}`;
  const filePath = path.join(uploadDir, fileName);
  const relativePath = `/${basePath}/${now.getFullYear()}/${now.getMonth() + 1}/${now.getDate()}/${fileName}`;

  // Move file
  await file.mv(filePath);

  return {
    path: relativePath,
    type: fileExtension.substring(1).toUpperCase(),
    size: file.size,
    physicalPath: filePath
  };
};

/**
 * @desc    Get all quotations
 * @route   GET /api/quotations
 * @access  Private/Admin
 */
exports.getQuotations = asyncHandler(async (req, res) => {
  const quotations = await Quotation.find().populate('user', 'name email phone');
  res.status(200).json({ success: true, count: quotations.length, data: quotations });
});

/**
 * @desc    Get single quotation
 * @route   GET /api/quotations/:id
 * @access  Private
 */
exports.getQuotation = asyncHandler(async (req, res, next) => {
  const quotation = await Quotation.findById(req.params.id)
    .populate('user', 'name email phone')
    .populate('payment', 'hoursPurchased purchaseOrderFile');
  
  if (!quotation) return next(new ErrorResponse('Quotation not found', 404));
  
  res.status(200).json({ success: true, data: quotation });
});

/**
 * @desc    User requests a new quotation
 * @route   POST /api/quotations
 * @access  Private
 */
exports.requestQuotation = asyncHandler(async (req, res, next) => {
  let savedOriginalFiles = [];
  let savedInfoFiles = [];

  try {
    const {
      projectName,
      description,
      deliverables,
      technicalInfo,
      resolution,
      deadline
    } = req.body;

    if (!projectName?.trim()) {
      return next(new ErrorResponse('Project name is required', 400));
    }

    // Normalize original files
    let originalFiles = [];
    if (req.files?.originalFiles) {
      originalFiles = Array.isArray(req.files.originalFiles)
        ? req.files.originalFiles
        : [req.files.originalFiles];
    }

    if (originalFiles.length === 0) {
      return next(new ErrorResponse('At least one original file is required', 400));
    }

    // Normalize info files
    let infoFiles = [];
    if (req.files?.infoFiles) {
      infoFiles = Array.isArray(req.files.infoFiles)
        ? req.files.infoFiles
        : [req.files.infoFiles];
    }

    // Save original files
    for (const file of originalFiles) {
      const fileData = await saveUploadedFile(file, '../uploads/project-files');
      savedOriginalFiles.push({
        originalFile: fileData.path,
        status: 'pending'
      });
    }

    // Save info files
    for (const file of infoFiles) {
      const fileData = await saveUploadedFile(file, '../uploads/info-files');
      savedInfoFiles.push(fileData.path);
    }

    // Create quotation
    const quotation = await Quotation.create({
      user: req.user.id,
      projectName: projectName.trim(),
      description: description?.trim(),
      technicalInfo: technicalInfo?.trim(),
      deliverables: deliverables?.trim(),
      resolution: resolution?.trim(),
      deadline: deadline ? new Date(deadline) : undefined,
      files: savedOriginalFiles,
      infoFiles: savedInfoFiles,
      status: 'requested'
    });

    // Admin Notification
    const adminUsers = await User.find({ role: 'admin' }).select('email');
    await Notification.create({
      user: quotation.user,
      title: 'New Quotation Request',
      message: `Your request has been sent to admin: ${quotation.projectName}`,
      type: 'quote_requested',
      quotation: quotation._id
    });

    await createAdminNotification(
      'New Quotation Request',
      `New quotation requested for project: ${projectName}`,
      'quote_requested',
      quotation._id
    );

    const emailData = {
      userName: req.user.name,
      userEmail: req.user.email,
      projectName,
      description: description || 'Not provided',
      technicalInfo: technicalInfo || 'Not provided',
      deliverables: deliverables || 'Not provided',
      date: new Date().toLocaleDateString(),
      currentYear: new Date().getFullYear(),
      supportEmail: 'global@precise3dm.com',
      adminDashboardLink:`${process.env.FRONTEND_URL}/app/admin/quotes/${quotation._id}`,
    };

    const adminEmails = adminUsers.map(user => user.email);
    if (adminEmails.length > 0) {
      await sendQuotationEmail(
        adminEmails,
        `New Quotation Request: ${projectName}`,
        'quotationRequestedToAdmin.html',
        emailData
      );
    }

    await sendQuotationEmail(
      req.user.email,
      `Quotation Request Received: ${projectName}`,
      'quotationRequestedToUser.html',
      emailData
    );

    // Socket.io Notification
    const io = req.app.get('io');
    if (io) {
      io.to(`user_${req.user.id}`).emit('quotation:requested', {
        user: req.user.id,
        projectName,
        quotationId: quotation._id,
        message: `Your quotation request for "${projectName}" was submitted successfully.`
      });

      io.to('admins').emit('new_quotation_arrived', {
        projectName,
        quotationId: quotation._id,
        requestedBy: {
          id: req.user.id,
          name: req.user.name,
          email: req.user.email
        },
        time: new Date()
      });
    }

    res.status(201).json({ success: true, data: quotation });

  } catch (err) {
    console.error('Error in requestQuotation:', err);

    // Cleanup uploaded files
    for (const f of savedOriginalFiles) {
      const absPath = path.join(__dirname, '..', f.originalFile);
      if (fs.existsSync(absPath)) fs.unlinkSync(absPath);
    }
    for (const f of savedInfoFiles) {
      const absPath = path.join(__dirname, '..', f);
      if (fs.existsSync(absPath)) fs.unlinkSync(absPath);
    }

    return next(
      err instanceof ErrorResponse
        ? err
        : new ErrorResponse('Failed to process quotation request', 500)
    );
  }
});

/**
 * @desc    Admin updates file hours and total hours
 * @route   PUT /api/quotations/:id/update-file-hours
 * @access  Private/Admin
 */
exports.raiseQuote = asyncHandler(async (req, res, next) => {
let files = [];
try {
  files = JSON.parse(req.body.files);
} catch (e) {
  return next(new ErrorResponse('Invalid files format', 400));
}

const {  totalHours, quotationFile } = req.body;


  // Validate input
  if (!Array.isArray(files) || files.length === 0) {
    return next(new ErrorResponse('Please provide valid file data', 400));
  }

  // Find the quotation
  const quotation = await Quotation.findById(req.params.id);
  if (!quotation) {
    return next(new ErrorResponse('Quotation not found', 404));
  }

  // Track updated file hours to sum up later if needed
  let totalRequiredFromFiles = 0;

  for (const fileUpdate of files) {
    const fileIndex = quotation.files.findIndex(
      (f) => f._id.toString() === fileUpdate.fileId
    );

    if (fileIndex === -1) {
      return next(
        new ErrorResponse(`File not found with ID: ${fileUpdate.fileId}`, 404)
      );
    }

    const file = quotation.files[fileIndex];

    // Validate and update required hour
    if (fileUpdate.requiredHour !== undefined) {
      if (isNaN(fileUpdate.requiredHour) || fileUpdate.requiredHour < 0) {
        return next(new ErrorResponse('Invalid required hour value', 400));
      }
      file.requiredHour = fileUpdate.requiredHour;
      totalRequiredFromFiles += fileUpdate.requiredHour;
    } else {
      totalRequiredFromFiles += file.requiredHour || 0;
    }

    // Optional updates
    if (fileUpdate.status) {
      file.status = fileUpdate.status;
    }

    if (fileUpdate.notes) {
      file.notes = fileUpdate.notes;
    }
  }

  // Determine the final total required hours
  if (totalHours !== undefined) {
    if (isNaN(totalHours) || totalHours < 0) {
      return next(new ErrorResponse('Invalid total hours value', 400));
    }
    quotation.requiredHour = totalHours;
  } else {
    quotation.requiredHour = totalRequiredFromFiles;
  }

  quotation.status = 'quoted';

 if (req.files && req.files.quotationFile) {
  const uploaded = await saveUploadedFile(req.files.quotationFile, 'uploads/quotations');
  quotation.quotationFile = uploaded.path;
}


  await quotation.save();

  // Notify the user
  const user = await User.findById(quotation.user);
  if (!user) {
    return next(new ErrorResponse('User not found', 404));
  }
  
  const emailData = {
  userName: user.name,
  userEmail: user.email,
  projectName: quotation.projectName,
  requiredHour: quotation.requiredHour,
  projectLink: `${process.env.FRONTEND_URL}/app/quotes/${quotation._id}`, // Replace with actual project link
  currentYear: new Date().getFullYear(),
};

 let attachments = [];

if (quotation.quotationFile) {
  const relativePath = quotation.quotationFile.replace(/^\/+/, ''); // remove any leading slash
  const absolutePath = path.resolve(__dirname, '..', relativePath);

  if (fs.existsSync(absolutePath)) {
    attachments.push({
      filename: path.basename(absolutePath),
      path: absolutePath,
    });
  } else {
    console.warn('Attachment file not found:', absolutePath);
  }
}

  const message = await loadEmailTemplate('quoteRaisedToUser.html', emailData);
  await sendQuotationEmail({
    email: user.email,
    subject: `Quote Ready: ${quotation.projectName}`,
    message,
    attachments // ✅ add here
  });

  
  await Notification.create({
    user: user._id,
    title: 'Project Hours Updated',
    message: `Admin updated hours for your project: ${quotation.projectName}`,
    type: 'quote_raised',
    quotation: quotation._id,
  });

  // Emit update via socket
  req.app.get('io').emit('quotation:hours-updated', {
    user: user._id,
    quotationId: quotation._id,
    message: `Hours updated for project ${quotation.projectName}`,
  });

  res.status(200).json({
    success: true,
    data: quotation,
    message: 'File hours updated successfully',
  });
});



/**
 * @desc    Update required hours for each file and total quotation hours
 * @route   PUT /api/quotations/:id/hours
 * @access  Private/Admin
 */
exports.updateRequiredHourAgain = asyncHandler(async (req, res, next) => {
  const { files, totalHours } = req.body;

  // Validate files
  if (!Array.isArray(files) || files.length === 0) {
    return next(new ErrorResponse('Please provide valid file data', 400));
  }

  // Find the quotation
  const quotation = await Quotation.findById(req.params.id);
  if (!quotation) {
    return next(new ErrorResponse('Quotation not found', 404));
  }

  let totalRequiredFromFiles = 0;

  for (const fileUpdate of files) {
    const fileIndex = quotation.files.findIndex(
      (f) => f._id.toString() === fileUpdate.fileId
    );

    if (fileIndex === -1) {
      return next(
        new ErrorResponse(`File not found with ID: ${fileUpdate.fileId}`, 404)
      );
    }

    const file = quotation.files[fileIndex];

    // Validate and update requiredHour
    if (fileUpdate.requiredHour !== undefined) {
      if (isNaN(fileUpdate.requiredHour) || fileUpdate.requiredHour < 0) {
        return next(new ErrorResponse('Invalid required hour value', 400));
      }
      file.requiredHour = fileUpdate.requiredHour;
      totalRequiredFromFiles += fileUpdate.requiredHour;
    } else {
      totalRequiredFromFiles += file.requiredHour || 0;
    }

    // Optional updates
    if (fileUpdate.status) {
      file.status = fileUpdate.status;
    }

    if (fileUpdate.notes) {
      file.notes = fileUpdate.notes;
    }
  }

  // Update main quotation's requiredHour
  if (totalHours !== undefined) {
    if (isNaN(totalHours) || totalHours < 0) {
      return next(new ErrorResponse('Invalid total hours value', 400));
    }
    quotation.requiredHour = totalHours;
  } else {
    quotation.requiredHour = totalRequiredFromFiles;
  }

  await quotation.save();

  const user = await User.findById(quotation.user);
  if (!user) return next(new ErrorResponse('User not found', 404));

  // Send email to user
  await sendQuotationEmail(
    user.email,
    `Updated Quote Hours: ${quotation.projectName}`,
    'quoteHourUpdated.html',
    {
      userName: user.name,
      projectName: quotation.projectName,
      requiredHour: quotation.requiredHour,
      currentYear: new Date().getFullYear(),
      projectLink: `${process.env.FRONTEND_URL}/app/quotes/${quotation._id}`,
    }
  );

  // Emit socket
  req.app.get('io').emit('quotation:hour-updated', {
    user: quotation.user,
    quotationId: quotation._id,
    requiredHour: quotation.requiredHour,
    message: `Quote hours updated for project ${quotation.projectName}`,
  });

  // Admin Notification
  await createAdminNotification(
    'Quote Hours Updated',
    `Quote hours updated for project: ${quotation.projectName} to ${quotation.requiredHour} hours`,
    'quote_updated',
    quotation._id
  );

  res.status(200).json({
    success: true,
    data: quotation,
    message: 'Required hours updated successfully',
  });
});


/**
 * @desc    User approves or rejects the quote
 * @route   PUT /api/quotations/:id/decision
 * @access  Private
 */
exports.userDecision = asyncHandler(async (req, res, next) => {
  const { status } = req.body;

  if (!['approved', 'rejected'].includes(status)) {
    return next(new ErrorResponse('Invalid status', 400));
  }

  const quotation = await Quotation.findById(req.params.id);
  if (!quotation) return next(new ErrorResponse('Quotation not found', 404));

  if (status === 'approved') {
    if (!quotation.requiredHour) {
      return next(new ErrorResponse('This quotation has no required hours set', 400));
    }

    const user = await User.findById(req.user.id);
    if (!user) return next(new ErrorResponse('User not found', 404));

    if (user.Hours < quotation.requiredHour) {
      return next(new ErrorResponse(
        `Not enough hours. You have ${user.Hours} hours but need ${quotation.requiredHour}`,
        400
      ));
    }

    user.Hours -= quotation.requiredHour;
    await user.save();

    quotation.approvedAt = Date.now();
  }

  // Update quotation status
  quotation.status = status;
  await quotation.save();

  // Get admin users to notify
  const adminUsers = await User.find({ role: 'admin' }).select('email');
  const adminEmails = adminUsers.map(user => user.email);

  // Email templates based on decision
  const emailTemplate = status === 'approved' 
    ? 'quoteApprovedToUser.html' 
    : 'quoteRejectedToUser.html';
  
  const adminEmailTemplate = status === 'approved'
    ? 'quoteApprovedToAdmin.html'
    : 'quoteRejectedToAdmin.html';

  const emailSubject = status === 'approved'
    ? `Quotation Approved: ${quotation.projectName}`
    : `Quotation Rejected: ${quotation.projectName}`;

  // Email to user
  await sendQuotationEmail(
    req.user.email,
    emailSubject,
    emailTemplate,
    {
      userName: req.user.name,
      projectName: quotation.projectName,
      requiredHour: quotation.requiredHour,
      remainingHours: quotation.user?.Hours ?? 'N/A',
      currentYear: new Date().getFullYear(),
      supportEmail: 'sales@precise3dm.com',
      approvalDate:new Date().toLocaleDateString(),
      contactLink:`https://us02web.zoom.us/j/5903189768?pwd=T3VucDArMUY1NGxNRU1NMnJMYnVuQT09`,
    }
  );

  // Email to admins
  await sendQuotationEmail(
    adminEmails,
    emailSubject,
    adminEmailTemplate,
    {
      userName: req.user.name,
      userEmail: req.user.email,
      projectName: quotation.projectName,
      requiredHour: quotation.requiredHour,
      currentYear: new Date().getFullYear(),
      date: new Date().toLocaleDateString(),
      approvalDate:new Date().getFullYear(),
      declineDate:new Date().getFullYear(),
      projectLink: `${process.env.FRONTEND_URL}/app/admin/quotes/${quotation._id}`,
      
    }
  );

  // Create notification
  await Notification.create({
    user: req.user.id,
    title: `Quotation ${status.charAt(0).toUpperCase() + status.slice(1)}`,
    message: `Your quotation "${quotation.projectName}" has been ${status}`,
    type: status === 'approved' ? 'quote_approved' : 'quote_rejected',
    quotation: quotation._id
  });
  
  // Create admin notification
  await createAdminNotification(
    `Quote ${status.charAt(0).toUpperCase() + status.slice(1)}`,
    `User ${status} the quote for project: ${quotation.projectName}`,
    status === 'approved' ? 'quote_approved' : 'quote_rejected',
    quotation._id
  );

  // Socket.io notification
  req.app.get('io').emit('quotation:decision', {
    user: quotation.user,
    quotationId: quotation._id,
    status,
    message: `Quotation ${status} for project ${quotation.projectName}`
  });

  res.status(200).json({
    success: true,
    data: quotation,
    message: status === 'approved' 
      ? 'Quotation approved and hours deducted' 
      : 'Quotation rejected'
  });
});

/**
 * @desc    User changes status of the quote without hour checks (for PO)
 * @route   PUT /api/quotations/:id/decision-po
 * @access  Private
 */
exports.userDecisionPO = asyncHandler(async (req, res, next) => {
  const { status } = req.body;

  if (!['approved', 'rejected'].includes(status)) {
    return next(new ErrorResponse('Invalid status', 400));
  }

  const quotation = await Quotation.findById(req.params.id);
  if (!quotation) return next(new ErrorResponse('Quotation not found', 404));

  quotation.status = status;
  if (status === 'approved') {
    quotation.approvedAt = Date.now();
  }
  await quotation.save();

  // Get admin users to notify
  const adminUsers = await User.find({ role: 'admin' }).select('email');
  const adminEmails = adminUsers.map(user => user.email);

  // Determine email templates based on status
  const emailTemplate = status === 'approved' 
    ? 'quoteApprovedToUser.html' 
    : 'quoteRejectedToUser.html';
  
  const adminEmailTemplate = status === 'approved'
    ? 'quoteApprovedToAdmin.html'
    : 'quoteRejectedToAdmin.html';

  const emailSubject = status === 'approved'
    ? `Quotation Approved (PO): ${quotation.projectName}`
    : `Quotation Rejected (PO): ${quotation.projectName}`;

  // Email to user
  await sendQuotationEmail(
    req.user.email,
    emailSubject,
    emailTemplate,
    {
      userName: req.user.name,
      projectName: quotation.projectName,
      requiredHour: quotation.requiredHour,
      remainingHours: quotation.user?.Hours ?? 'N/A',
      approvalDate:  new Date().toLocaleDateString(),
      currentYear: new Date().getFullYear(),
      supportEmail: 'global@precise3dm.com',
      approvalDate:new Date().toLocaleDateString(),
      contactLink:`https://us02web.zoom.us/j/5903189768?pwd=T3VucDArMUY1NGxNRU1NMnJMYnVuQT09`,
    }
  );

  // Email to admins
  await sendQuotationEmail(
    adminEmails,
    emailSubject,
    adminEmailTemplate,
    {
      userName: req.user.name,
      userEmail: req.user.email,
      projectName: quotation.projectName,
      requiredHour: quotation.requiredHour,
           approvalDate:new Date().getFullYear(),
      declineDate:new Date().getFullYear(),
      currentYear: new Date().getFullYear(),
       projectLink: `${process.env.FRONTEND_URL}/app/admin/quotes/${quotation._id}`
    }
  );

  // Create notification
  await Notification.create({
    user: req.user.id,
    title: `Quotation ${status.charAt(0).toUpperCase() + status.slice(1)} (PO)`,
    message: `Your quotation "${quotation.projectName}" has been ${status}`,
    type: status === 'approved' ? 'quote_approved' : 'quote_rejected',
    quotation: quotation._id
  });
  
  // Create admin notification
  await createAdminNotification(
    `Quote ${status.charAt(0).toUpperCase() + status.slice(1)} (PO)`,
    `User ${status} the quote with PO for project: ${quotation.projectName}`,
    status === 'approved' ? 'quote_po_approved' : 'quote_po_rejected',
    quotation._id
  );

  // Emit socket event
  req.app.get('io').emit('quotation:decision', {
    user: quotation.user,
    quotationId: quotation._id,
    status,
    message: `Quotation ${status} (PO) for project ${quotation.projectName}`
  });

  res.status(200).json({
    success: true,
    data: quotation,
    message: `Quotation ${status}`
  });
});

/**
 * @desc    Mark quotation as ongoing
 * @route   PUT /api/quotations/:id/ongoing
 * @access  Private/Admin
 */
exports.markQuotationOngoing = asyncHandler(async (req, res, next) => {
  const quotation = await Quotation.findById(req.params.id);

  if (!quotation) {
    return next(new ErrorResponse('Quotation not found', 404));
  }

  if (quotation.status !== 'approved') {
    return next(new ErrorResponse('Quotation must be approved before it can be marked as ongoing', 400));
  }

  quotation.status = 'ongoing';
  quotation.startedAt = Date.now();
  await quotation.save();

  // Get user details for email
  const user = await User.findById(quotation.user);
  if (!user) return next(new ErrorResponse('User not found', 404));

  // Email to user
  await sendQuotationEmail(
    user.email,
    `Work Started: ${quotation.projectName}`,
    'workStartedToUser.html',
    {
      userName: user.name,
      startDate:  new Date().toLocaleDateString(),
      projectName: quotation.projectName,
      expectedCompletion: 'within the agreed timeframe',
      supportEmail: 'global@precise3dm.com',
      currentYear: new Date().getFullYear(),
    }
  );

  // Create user notification
  await Notification.create({
    user: quotation.user,
    title: 'Work Started',
    message: `Work has started on your project "${quotation.projectName}"`,
    
    type: 'quote_ongoing',
    quotation: quotation._id
  });
  
  // Create admin notification
  await createAdminNotification(
    'Project Started',
    `Work has started on project: ${quotation.projectName}`,
    'quote_ongoing',
    quotation._id
  );

  // Socket.io notification
  req.app.get('io').emit('quotation:ongoing', {
    user: quotation.user,
    quotationId: quotation._id,
    message: `Work started on project ${quotation.projectName}`
  });
  
  res.status(200).json({
    success: true,
    data: quotation,
    message: 'Quotation marked as ongoing'
  });
});

/**
 * @desc    Admin completes the work and uploads file
 * @route   PUT /api/quotations/:id/complete
 * @access  Private/Admin
 */
exports.completeQuotation = asyncHandler(async (req, res, next) => {
  let savedFiles = [];
  
  try {
    const quotation = await Quotation.findById(req.params.id);
    if (!quotation) return next(new ErrorResponse('Quotation not found', 404));

    // Check if files exist
    if (!req.files?.completedFiles) {
      return next(new ErrorResponse('No completed files were uploaded', 400));
    }

    // Normalize files (handle single file or array)
    const completedFiles = Array.isArray(req.files.completedFiles) 
      ? req.files.completedFiles 
      : [req.files.completedFiles];

    // Check if we have matching original files to complete
    if (completedFiles.length > quotation.files.length) {
      return next(new ErrorResponse(
        `Cannot upload ${completedFiles.length} completed files when only ${quotation.files.length} original files exist`,
        400
      ));
    }

    // Save all completed files and update corresponding file tracking entries
    for (let i = 0; i < completedFiles.length; i++) {
      const file = completedFiles[i];
      const fileInfo = await saveUploadedFile(file, '../completed_files');
      
      // Update the corresponding file tracking entry
      if (quotation.files[i]) {
        quotation.files[i].completedFile = fileInfo.path;
        quotation.files[i].status = 'completed';
        quotation.files[i].uploadedAt = new Date();
        
        savedFiles.push({
          path: fileInfo.path,
          type: fileInfo.type,
          size: fileInfo.size,
          physicalPath: fileInfo.physicalPath,
          originalFileIndex: i
        });
      }
    }

    // Check if all files are now completed
    const allFilesCompleted = quotation.files.every(file => file.status === 'completed');
    if (allFilesCompleted) {
      quotation.status = 'completed';
      quotation.completedAt = Date.now();
    }

    await quotation.save();

    // Get user details for email
    const user = await User.findById(quotation.user);
    if (!user) return next(new ErrorResponse('User not found', 404));

    // Prepare download links for email
    const downloadLinks = savedFiles.map(file => 
  `<li><a class="button" href="${process.env.BACKEND_URL.replace(/\/$/, '')}/${file.path.replace(/^\//, '')}">Download File ${file.originalFileIndex + 1}</a></li>`
).join('');
const htmlDownloadLinks = `<ul>${downloadLinks}</ul>`;

    // Email to user
    await sendQuotationEmail(
      user.email,
      `Project Completed: ${quotation.projectName}`,
      'projectCompletedToUser.html',
      {
        userName: user.name,
        completionDate: new Date().toLocaleDateString(),
        hoursSpent: quotation.requiredHour,
        projectName: quotation.projectName,
        currentYear: new Date().getFullYear(),
        downloadLinks: downloadLinks,
        supportEmail: 'sales@precise3dm.com',
        completedFilesCount: completedFiles.length,
        totalFilesCount: quotation.files.length
      }
    );
    
    // Create user notification
    await Notification.create({
      user: quotation.user,
      title: allFilesCompleted ? 'Project Completed' : 'Files Updated',
      message: allFilesCompleted 
        ? `Your project "${quotation.projectName}" has been completed` 
        : `${completedFiles.length} files were added to your project "${quotation.projectName}"`,
      type: allFilesCompleted ? 'quote_completed' : 'files_updated',
      quotation: quotation._id
    });

    // Create admin notification
    await createAdminNotification(
      allFilesCompleted ? 'Project Completed' : 'Files Updated',
      allFilesCompleted
        ? `Project completed: ${quotation.projectName}`
        : `${completedFiles.length} files added to project: ${quotation.projectName}`,
      allFilesCompleted ? 'quote_completed' : 'files_updated',
      quotation._id
    );

    // Socket.io notification
    const io = req.app.get('io');
    if (io) {
      io.to(`user_${quotation.user}`).emit(allFilesCompleted ? 'quotation:completed' : 'quotation:files_updated', {
        user: quotation.user,
        quotationId: quotation._id,
        message: allFilesCompleted
          ? `Quotation completed for ${quotation.projectName}`
          : `${completedFiles.length} files added to ${quotation.projectName}`,
        completedFiles: completedFiles.length,
        totalFiles: quotation.files.length
      });
    }

    res.status(200).json({ 
      success: true, 
      data: quotation,
      message: allFilesCompleted
        ? 'Project marked as completed'
        : 'Files added successfully'
    });

  } catch (err) {
    console.error('Error in completeQuotation:', err);
    
    // Clean up any uploaded files if error occurred
    for (const file of savedFiles) {
      if (file.physicalPath && fs.existsSync(file.physicalPath)) {
        fs.unlinkSync(file.physicalPath);
      }
    }
    
    return next(err instanceof ErrorResponse ? err : new ErrorResponse('Failed to process completed files', 500));
  }
});

/**
 * @desc    User updates their quotation request
 * @route   PUT /api/quotations/:id
 * @access  Private
 */
exports.updateQuotation = asyncHandler(async (req, res, next) => {
  const quotation = await Quotation.findById(req.params.id);

  if (!quotation) {
    return next(new ErrorResponse('Quotation not found', 404));
  }

  // Check ownership
  if (quotation.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new ErrorResponse('Not authorized to update this quotation', 403));
  }

  // Check if quotation can be updated
  if (!['requested', 'quoted'].includes(quotation.status)) {
    return next(new ErrorResponse('Quotation cannot be updated in its current state', 400));
  }

  const { 
    projectName, 
    description, 
    technicalInfo, 
    deliverables,
    resolution,
    requiredHour,
    deadline
  } = req.body;

  // Update basic fields
  if (projectName) quotation.projectName = projectName.trim();
  if (description) quotation.description = description.trim();
  if (technicalInfo) quotation.technicalInfo = technicalInfo.trim();
  if (deliverables) quotation.deliverables = deliverables.trim();
  if (resolution) quotation.resolution = resolution.trim();
  if (requiredHour) quotation.requiredHour = Number(requiredHour);
  if (deadline) quotation.deadline = new Date(deadline);

  let newFileInfo = null;
  let newInfoFileInfo = null;

  try {
    // Handle main file replacement
    if (req.files?.file) {
      const file = req.files.file;
      
      // Validate file size
      if (file.size > MAX_FILE_SIZE) {
        throw new ErrorResponse(`File exceeds ${MAX_FILE_SIZE / (1024 * 1024)}MB limit`, 400);
      }

      // Save new file
      newFileInfo = await saveUploadedFile(file, '../uploads/project-files');

      // Delete old file if it exists
      if (quotation.file) {
        const oldFilePath = path.join(__dirname, `..${quotation.file}`);
        if (fs.existsSync(oldFilePath)) {
          fs.unlinkSync(oldFilePath);
        }
      }

      quotation.file = newFileInfo.path;
      quotation.fileType = newFileInfo.type;
      quotation.fileSize = newFileInfo.size;
    }

    // Handle infoFile replacement
    if (req.files?.infoFile) {
      const infoFile = req.files.infoFile;
      
      // Validate file size
      if (infoFile.size > MAX_FILE_SIZE) {
        throw new ErrorResponse(`Info file exceeds ${MAX_FILE_SIZE / (1024 * 1024)}MB limit`, 400);
      }

      // Save new infoFile
      newInfoFileInfo = await saveUploadedFile(infoFile, '../uploads/info-files');

      // Delete old infoFile if it exists
      if (quotation.infoFile) {
        const oldInfoFilePath = path.join(__dirname, `..${quotation.infoFile}`);
        if (fs.existsSync(oldInfoFilePath)) {
          fs.unlinkSync(oldInfoFilePath);
        }
      }

      quotation.infoFile = newInfoFileInfo.path;
    }

    // Reset status if admin had previously quoted
    if (quotation.status === 'quoted' && req.user.role === 'user') {
      quotation.status = 'requested';
      quotation.quoteAmount = undefined;
      quotation.quoteDetails = undefined;
      quotation.quotedBy = undefined;
      quotation.quotedAt = undefined;
    }

    await quotation.save();

    // Create notification
    const notificationMessage = req.user.role === 'admin' 
      ? `Admin updated quotation for project: ${quotation.projectName}`
      : `User updated quotation for project: ${quotation.projectName}`;

    await createAdminNotification(
      'Quotation Updated',
      notificationMessage,
      'quotation_updated',
      quotation._id
    );

    // Emit socket update
    const io = req.app.get('io');
    if (io) {
      io.to(`user_${quotation.user}`).emit('quotation:updated', {
        quotationId: quotation._id,
        projectName: quotation.projectName,
        status: quotation.status,
        updatedBy: req.user.id,
        message: `Quotation for "${quotation.projectName}" has been updated`
      });

      if (req.user.role === 'user') {
        io.to('admins').emit('quotation:userUpdated', {
          user: quotation.user,
          quotationId: quotation._id,
          projectName: quotation.projectName,
          message: `User updated quotation for ${quotation.projectName}`
        });
      }
    }

    res.status(200).json({
      success: true,
      data: quotation
    });

  } catch (err) {
    console.error('Error in updateQuotation:', err);
    
    // Clean up new files if update failed
    try {
      if (newFileInfo?.physicalPath && fs.existsSync(newFileInfo.physicalPath)) {
        fs.unlinkSync(newFileInfo.physicalPath);
      }
      if (newInfoFileInfo?.physicalPath && fs.existsSync(newInfoFileInfo.physicalPath)) {
        fs.unlinkSync(newInfoFileInfo.physicalPath);
      }
    } catch (cleanupError) {
      console.error('Error cleaning up new files:', cleanupError);
    }
    
    return next(err instanceof ErrorResponse ? err : new ErrorResponse('Failed to update quotation', 500));
  }
});

/**
 * @desc    Delete quotation
 * @route   DELETE /api/quotations/:id
 * @access  Private/Admin
 */
exports.deleteQuotation = asyncHandler(async (req, res, next) => {
  const quotation = await Quotation.findById(req.params.id);
  
  if (!quotation) {
    return next(new ErrorResponse('Quotation not found', 404));
  }

  // Delete associated files if they exist
  if (quotation.file && fs.existsSync(path.join(__dirname, `..${quotation.file}`))) {
    fs.unlinkSync(path.join(__dirname, `..${quotation.file}`));
  }

  if (quotation.completedFile && fs.existsSync(path.join(__dirname, `..${quotation.completedFile}`))) {
    fs.unlinkSync(path.join(__dirname, `..${quotation.completedFile}`));
  }

  await quotation.deleteOne();

  res.status(200).json({ 
    success: true, 
    data: {},
    message: 'Quotation deleted successfully'
  });
});

/**
 * @desc    Get all quotations for current user
 * @route   GET /api/quotations/my
 * @access  Private
 */
exports.getUserQuotations = asyncHandler(async (req, res) => {
  const quotations = await Quotation.find({ user: req.user.id })
    .populate('user', 'name email phone')
    .populate('payment', 'hoursPurchased purchaseOrderFile');
  
  res.status(200).json({ 
    success: true, 
    count: quotations.length, 
    data: quotations 
  });
});

/**
 * @desc    Get all quotations for a specific user
 * @route   GET /api/quotations/user/:id
 * @access  Private/Admin
 */
exports.getUserQuotationsById = asyncHandler(async (req, res) => {
  const quotations = await Quotation.find({ user: req.params.id })
    .populate('user', 'name email phone');

  res.status(200).json({ 
    success: true, 
    count: quotations.length, 
    data: quotations 
  });
});

/**
 * @desc    Update PO status
 * @route   PUT /api/quotations/:id/po-status
 * @access  Private/Admin
 */
exports.updatePoStatus = asyncHandler(async (req, res, next) => {
  const { poStatus } = req.body;

  if (!poStatus) {
    return next(new ErrorResponse('Please provide a PO status', 400));
  }

  if (!VALID_PO_STATUSES.includes(poStatus)) {
    return next(new ErrorResponse('Invalid PO status', 400));
  }

  const quotation = await Quotation.findById(req.params.id);
  
  if (!quotation) {
    return next(new ErrorResponse('Quotation not found', 404));
  }

  // Update PO status
  quotation.poStatus = poStatus;
  quotation.updatedAt = Date.now();

  // If PO status is being updated to 'approved', automatically set user decision to 'approved'
  if (poStatus === 'approved') {
    quotation.status = 'approved';
    quotation.approvedAt = Date.now();
    
    // Get user details for notification
    const user = await User.findById(quotation.user);
    if (!user) {
      console.error(`User not found for quotation ${quotation._id}`);
    }

    // Create user notification
    await Notification.create({
      user: quotation.user,
      title: 'Quotation Approved via PO',
      message: `Your quotation "${quotation.projectName}" has been approved via purchase order`,
      type: 'quote_approved',
      quotation: quotation._id
    });

    // Email to user if user exists
    if (user) {
      await sendQuotationEmail(
        user.email,
        `Quotation Approved via PO: ${quotation.projectName}`,
        'quoteApprovedToUser.html',
        {
          userName: user.name,
          projectName: quotation.projectName,
          requiredHour: quotation.requiredHour,
          currentYear: new Date().getFullYear(),
          supportEmail: 'sales@precise3dm.com'
        }
      );
    }
  }

  await quotation.save();

  // Create admin notification
  await createAdminNotification(
    'PO Status Updated',
    `PO status changed to ${poStatus} for quotation ${quotation._id}`,
    'po_status_updated',
    quotation._id
  );

  // Socket.io notification
  req.app.get('io').emit('quotation:po-status-updated', {
    user: quotation.user,
    quotationId: quotation._id,
    poStatus,
    message: `PO status updated to ${poStatus} for project ${quotation.projectName}`
  });

  res.status(200).json({
    success: true,
    data: quotation
  });
});

/**
 * @desc    User submits rejection message for a quotation
 * @route   PUT /api/quotations/:id/reject-with-message
 * @access  Private
 */
exports.rejectWithMessage = asyncHandler(async (req, res, next) => {
  const { rejectionReason, rejectionMessage } = req.body;
  
  // Validate input
  if (!rejectionReason || !['price', 'timeline', 'requirements', 'other', 'user_rejection'].includes(rejectionReason)) {
    return next(new ErrorResponse('Invalid rejection reason', 400));
  }

  if (!rejectionMessage || rejectionMessage.trim().length < 2) {
    return next(new ErrorResponse('Please provide a detailed rejection message (at least 10 characters)', 400));
  }

  const quotation = await Quotation.findById(req.params.id);
  if (!quotation) return next(new ErrorResponse('Quotation not found', 404));

  quotation.status = 'rejected';
  quotation.rejectionReason = rejectionReason;
  quotation.rejectionDetails = rejectionMessage.trim();
  quotation.rejectedBy = req.user.id;
  quotation.rejectedAt = new Date();
  await quotation.save();

  // Get admin users to notify
  const adminUsers = await User.find({ role: 'admin' }).select('email');

  // Email to admins
  const adminEmails = adminUsers.map(user => user.email);
  if (adminEmails.length > 0) {
    await sendQuotationEmail(
      adminEmails,
      `Quotation Rejected: ${quotation.projectName}`,
      'quotationRejectedWithMessage.html',
      {
        userName: req.user?.name,
        userEmail: req.user?.email,
        projectName: quotation.projectName,
        rejectionMessage: quotation.rejectionDetails,
        date: new Date().toLocaleDateString(),
        currentYear: new Date().getFullYear(),
        projectLink: `${process.env.FRONTEND_URL}/admin/quotes/${quotation._id}`
      }
    );
  }

  // Create notification
  await Notification.create({
    user: req.user.id,
    title: 'Quotation Rejected',
    message: `You rejected the quotation for "${quotation.projectName}"`,
    type: 'quote_rejected',
    quotation: quotation._id
  });

  // Create admin notification
  await createAdminNotification(
    'Quotation Rejected with Message',
    `User rejected quotation for "${quotation.projectName}" with a message`,
    'quote_rejected',
    quotation._id
  );

  // Socket.io notification
  req.app.get('io').emit('quotation:rejected-with-message', {
    user: quotation.user,
    quotationId: quotation._id,
    message: `Quotation rejected with message for ${quotation.projectName}`
  });

  res.status(200).json({
    success: true,
    data: quotation,
    message: 'Quotation rejected successfully'
  });
});

exports.deleteQuoteFile = asyncHandler(async (req, res, next) => {
  const { id, fileId } = req.params;

  // Find the quotation
  const quotation = await Quotation.findById(id);
  if (!quotation) {
    return next(new ErrorResponse('Quotation not found', 404));
  }

  // Find the file to delete
  const fileIndex = quotation.files.findIndex(
    (f) => f._id.toString() === fileId
  );

  if (fileIndex === -1) {
    return next(new ErrorResponse('File not found in this quotation', 404));
  }

  // Store the required hour of the file to deduct later
  const deletedFile = quotation.files[fileIndex];
  const deductedHours = deletedFile.requiredHour || 0;

  // Remove the file
  quotation.files.splice(fileIndex, 1);

  // Reduce the total required hours
  quotation.requiredHour = Math.max(
    0,
    (quotation.requiredHour || 0) - deductedHours
  );

  await quotation.save();

  // Emit update via socket
  req.app.get('io').emit('quotation:file-deleted', {
    quotationId: quotation._id,
    fileId: fileId,
    message: `A file was deleted from project ${quotation.projectName}`,
    deductedHours,
    updatedTotalHours: quotation.requiredHour,
  });

  res.status(200).json({
    success: true,
    data: quotation,
    message: `File deleted successfully and ${deductedHours} hour(s) deducted from total`,
  });
});

exports.reportQuotationIssues = asyncHandler(async (req, res, next) => {
  const { fileReports, mainNote } = req.body;

  if (!Array.isArray(fileReports)) {
    return next(new ErrorResponse("fileReports must be an array", 400));
  }

  const quotation = await Quotation.findById(req.params.id);
  if (!quotation) {
    return next(new ErrorResponse("Quotation not found", 404));
  }

  // Safely update file reports
  for (const report of fileReports) {
    const { index, status, note } = report;

    if (
      typeof index !== 'number' ||
      (status !== 'reported' && status !== 'ok')
    ) {
      return next(new ErrorResponse("Invalid file report format", 400));
    }

    const file = quotation.files[index];
    if (!file) {
      return next(
        new ErrorResponse(`No file found at index ${index}`, 400)
      );
    }

    file.userReportedStatus = status;
    file.userNotes = note?.trim() || '';
  }

  // Only update notes and status if mainNote is provided
  if (typeof mainNote === 'string' && mainNote.trim() !== '') {
    quotation.notes = mainNote.trim();
    quotation.status = 'reported';
  }

  await quotation.save();

  await createAdminNotification(
    'User Feedback on Files',
    `User provided feedback on files in quotation: ${quotation.projectName}`,
    'quotation_issue_reported',
    quotation._id
  );

  res.status(200).json({
    success: true,
    message: 'Issue report submitted successfully',
    data: quotation
  });
});

exports.uploadIssuedFiles = asyncHandler(async (req, res, next) => {
  if (!req.files || Object.keys(req.files).length === 0) {
    return next(new ErrorResponse("No files were uploaded", 400));
  }

  try {
    const quotation = await Quotation.findById(req.params.id);
    if (!quotation) {
      return next(new ErrorResponse("Quotation not found", 404));
    }

    // Get file IDs from metadata
    const fileIds = req.body.fileIds ? JSON.parse(req.body.fileIds) : [];
    const savedFiles = [];

    // Process files sequentially (not with forEach)
    const fileEntries = Object.entries(req.files);
    for (const [key, uploadedFile] of fileEntries) {
      try {
        const match = key.match(/^issuedFiles\[(\d+)\]$/);
        if (!match) continue;

        const uploadIndex = parseInt(match[1]);
        const fileId = fileIds[uploadIndex];
        
        if (!fileId) continue;

        // Find the file in quotation.files
        const fileToUpdate = quotation.files.find(f => f._id.toString() === fileId);
        if (!fileToUpdate) continue;
        
        // Skip if file doesn't need reuploading
        if (fileToUpdate.userReportedStatus !== 'reported') continue;

        // Create upload directory if it doesn't exist
        const uploadDir = path.join(__dirname, '../uploads');
        if (!fs.existsSync(uploadDir)) {
          fs.mkdirSync(uploadDir, { recursive: true });
        }

        const fileName = `${Date.now()}_${uploadedFile.name}`;
        const fileInfo = {
          path: `/uploads/${fileName}`,
          physicalPath: path.join(uploadDir, fileName)
        };

        // Save file to disk
        await new Promise((resolve, reject) => {
          uploadedFile.mv(fileInfo.physicalPath, (err) => {
            if (err) reject(err);
            else resolve();
          });
        });

        // Update file record
        fileToUpdate.completedFile = fileInfo.path;
        fileToUpdate.status = 'completed';
        fileToUpdate.userReportedStatus = 'ok';
        fileToUpdate.uploadedAt = new Date();

        savedFiles.push(fileInfo);
      } catch (fileErr) {
        console.error(`Error processing file ${key}:`, fileErr);
        continue; // Skip to next file if one fails
      }
    }

    if (savedFiles.length === 0) {
      return next(new ErrorResponse(
        "No valid files were processed. Either files don't need reuploading or IDs didn't match.",
        400
      ));
    }

    // Check if all files are now completed
    const allCompleted = quotation.files.every(f => f.status === 'completed');
    if (allCompleted) {
      quotation.status = 'completed';
      quotation.completedAt = new Date();
    }

    await quotation.save();

    return res.status(200).json({
      success: true,
      message: `${savedFiles.length} file(s) reuploaded successfully`,
      data: {
        quotation,
        processedFiles: savedFiles.map(f => f.path)
      }
    });

  } catch (err) {
    console.error("Error in uploadIssuedFiles:", err);
    
    return next(new ErrorResponse(
      `File upload failed: ${err.message}`,
      500
    ));
  }
});


