const RateConfig = require('../models/RateConfig');
const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../utils/asyncHandler');

// @desc    Get current active rate for a country
// @route   GET /api/v1/rateconfig/current/:country
// @access  Public
exports.getCurrentRateByCountry = asyncHandler(async (req, res, next) => {
  const country = req.params.country.toUpperCase();
  
  const rate = await RateConfig.findOne({ 
    isActive: true,
    country: country
  }).sort({ effectiveFrom: -1 });

  if (!rate) {
    return next(
      new ErrorResponse(`No active rate configuration found for country ${country}`, 404)
    );
  }

  res.status(200).json({
    success: true,
    data: rate
  });
});

// @desc    Get all rate configurations
// @route   GET /api/v1/rateconfig
// @access  Private/Admin
exports.getRates = asyncHandler(async (req, res, next) => {
  res.status(200).json(res.advancedResults);
});

// @desc    Get single rate configuration
// @route   GET /api/v1/rateconfig/:id
// @access  Private/Admin
exports.getRate = asyncHandler(async (req, res, next) => {
  const rate = await RateConfig.findById(req.params.id);

  if (!rate) {
    return next(
      new ErrorResponse(`Rate config not found with id of ${req.params.id}`, 404)
    );
  }

  res.status(200).json({
    success: true,
    data: rate
  });
});

// @desc    Create new rate configuration
// @route   POST /api/v1/rateconfig
// @access  Private/Admin
exports.createRate = asyncHandler(async (req, res, next) => {
  // Validate country code
  if (req.body.country) {
    req.body.country = req.body.country.toUpperCase();
  }

  // If making this rate active, deactivate previous rates for same country
  if (req.body.isActive !== false) {
    await RateConfig.updateMany(
      { country: req.body.country },
      { isActive: false }
    );
  }

  const rate = await RateConfig.create({
    ...req.body,
    currency: 'USD' // Force USD currency
  });

  res.status(201).json({
    success: true,
    data: rate
  });
});

// @desc    Update rate configuration
// @route   PUT /api/v1/rateconfig/:id
// @access  Private/Admin
exports.updateRate = asyncHandler(async (req, res, next) => {
  let rate = await RateConfig.findById(req.params.id);

  if (!rate) {
    return next(
      new ErrorResponse(`Rate config not found with id of ${req.params.id}`, 404)
    );
  }

  // Validate country code if provided
  if (req.body.country) {
    req.body.country = req.body.country.toUpperCase();
  }

  // If making this rate active, deactivate other rates for same country
  if (req.body.isActive === true) {
    await RateConfig.updateMany(
      { 
        _id: { $ne: req.params.id },
        country: req.body.country || rate.country
      },
      { isActive: false }
    );
  }

  // Ensure currency remains USD
  if (req.body.currency && req.body.currency !== 'USD') {
    return next(
      new ErrorResponse('Only USD currency is supported', 400)
    );
  }

  rate = await RateConfig.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  });

  res.status(200).json({
    success: true,
    data: rate
  });
});

// @desc    Delete rate configuration
// @route   DELETE /api/v1/rateconfig/:id
// @access  Private/Admin
exports.deleteRate = asyncHandler(async (req, res, next) => {
  const deletedRate = await RateConfig.findByIdAndDelete(req.params.id);

  if (!deletedRate) {
    return next(
      new ErrorResponse(`Rate config not found with id of ${req.params.id}`, 404)
    );
  }

  res.status(200).json({
    success: true,
    message: `Rate config with id ${req.params.id} has been deleted.`,
    data: {}
  });
});