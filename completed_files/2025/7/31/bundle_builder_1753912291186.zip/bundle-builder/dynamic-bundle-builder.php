<?php
/**
 * Plugin Name: Dynamic Bundle Builder
 * Description: A WooCommerce bundle builder plugin that allows admins to add multiple steps and select categories, with options for single or multiple product selection.
 * Version: 1.2
 * Author: Your Name
 */

// Prevent direct access to this file
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Plugin activation hook
register_activation_hook(__FILE__, 'bundle_builder_activate');

function bundle_builder_activate()
{
    // Ensure WooCommerce is active
    if (!class_exists('WooCommerce')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die('WooCommerce is required for this plugin to work.');
    }
}

// Enqueue necessary scripts and styles
add_action('wp_enqueue_scripts', 'bundle_builder_enqueue_scripts');
function bundle_builder_enqueue_scripts()
{
    // Append the current time as a version to prevent caching (only for development/testing)
    $script_version = time(); // This changes on every page load, preventing caching

    // Enqueue the CSS file with the version to prevent caching
    wp_enqueue_style('bundle-builder-css', plugin_dir_url(__FILE__) . 'assets/bundle_builder.css', array(), $script_version);

    // Enqueue the JS file with the version to prevent caching, and load it in the footer
    wp_enqueue_script('bundle-builder-js', plugin_dir_url(__FILE__) . 'assets/bundle_builder.js', array('jquery'), $script_version, true);
}

// Localize AJAX URL
add_action('wp_enqueue_scripts', 'bundle_builder_localize_script');
function bundle_builder_localize_script()
{
    wp_localize_script('bundle-builder-js', 'bundle_builder', array(
        'ajax_url' => admin_url('admin-ajax.php')
    ));
}

// Create the bundle builder admin settings page
add_action('admin_menu', 'bundle_builder_add_admin_menu');
function bundle_builder_add_admin_menu()
{
    add_menu_page(
        'Bundle Builder Settings',
        'Bundle Builder',
        'manage_options',
        'bundle-builder-settings',
        'bundle_builder_settings_page',
        'dashicons-admin-generic',
        100
    );
}

// Display the settings page for creating, editing, and deleting steps
function bundle_builder_settings_page()
{
    if (isset($_POST['bundle_builder_settings_submit'])) {
        // Save steps array
        $steps = array();
        if (!empty($_POST['step_name']) && is_array($_POST['step_name'])) {
            foreach ($_POST['step_name'] as $key => $name) {
                $steps[] = array(
                    'name' => sanitize_text_field($name),
                    'category' => sanitize_text_field($_POST['step_category'][$key]),
                    'selection_type' => sanitize_text_field($_POST['step_selection_type'][$key]),
                    'mandatory' => isset($_POST['step_mandatory'][$key]) ? 1 : 0 // Check if mandatory is set
                );
            }
        }
        update_option('bundle_builder_steps', $steps);

        echo '<div class="updated"><p>Settings saved.</p></div>';
    }

    // Retrieve saved steps
    $bundle_builder_steps = get_option('bundle_builder_steps', array());

    ?>
    <div class="wrap">
        <style>
            .bundle-step-item {
                display: flex;
                justify-content: space-between;
                align-items: center;
            }

            .admin_btns {
                margin-top: 30px;
            }
        </style>
        <h1>Bundle Builder Settings</h1>
        <form method="POST">
            <div id="bundle-steps">

                <?php if (!empty($bundle_builder_steps)): ?>
                    <?php foreach ($bundle_builder_steps as $index => $step): ?>
                        <div class="bundle-step-item">
                            <h3>Step <?php echo $index + 1; ?></h3>
                            <label for="step_name_<?php echo $index; ?>">Step Name:</label>
                            <input type="text" name="step_name[]" id="step_name_<?php echo $index; ?>"
                                value="<?php echo esc_attr($step['name']); ?>" />

                            <label for="step_category_<?php echo $index; ?>">Category:</label>
                            <input type="text" name="step_category[]" id="step_category_<?php echo $index; ?>"
                                value="<?php echo esc_attr($step['category']); ?>" />

                            <label for="step_selection_type_<?php echo $index; ?>">Selection Type:</label>
                            <select name="step_selection_type[]" id="step_selection_type_<?php echo $index; ?>">
                                <option value="single" <?php selected($step['selection_type'], 'single'); ?>>Single</option>
                                <option value="multi" <?php selected($step['selection_type'], 'multi'); ?>>Multi</option>
                            </select>

                            <label for="step_mandatory_<?php echo $index; ?>">
                                <input type="checkbox" name="step_mandatory[]" id="step_mandatory_<?php echo $index; ?>" <?php checked($step['mandatory'], 1); ?> />
                                Mandatory Step
                            </label>

                            <button type="button" class="remove-step button-secondary">Remove Step</button>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <div class="admin_btns">
                <button type="button" id="add-step" class="button-primary">Add Step</button>

                <input type="submit" name="bundle_builder_settings_submit" class="button-primary" value="Save Settings" />
            </div>
        </form>
    </div>

    <script type="text/javascript">
        jQuery(document).ready(function ($) {
            $('#add-step').on('click', function () {
                var stepCount = $('#bundle-steps .bundle-step-item').length;
                var newStep =
                    <div class="bundle-step-item">
                        <h3>Step  + (stepCount + 1) + </h3>
                        <label for="step_name_ + stepCount + ">Step Name:</label>
                        <input type="text" name="step_name[]" id="step_name_ + stepCount + " />

                        <label for="step_category_ + stepCount + ">Category:</label>
                        <input type="text" name="step_category[]" id="step_category_ + stepCount + " />

                        <label for="step_selection_type_ + stepCount + ">Selection Type:</label>
                        <select name="step_selection_type[]" id="step_selection_type_ + stepCount + ">
                            <option value="single">Single</option>
                            <option value="multi">Multi</option>
                        </select>

                        <label for="step_mandatory_ + stepCount + ">
                            <input type="checkbox" name="step_mandatory[]" id="step_mandatory_ + stepCount + " />
                            Mandatory Step
                        </label>

                        <button type="button" class="remove-step button-secondary">Remove Step</button>
                    </div>
                    ;
                $('#bundle-steps').append(newStep);
            });

            $(document).on('click', '.remove-step', function () {
                $(this).closest('.bundle-step-item').remove();
            });
        });
    </script>
    <?php
}

// Shortcode to display the bundle builder
add_shortcode('bundle_builder', 'bundle_builder_shortcode');
function bundle_builder_shortcode()
{
    ob_start();

    // Retrieve the steps from the saved settings
    $bundle_builder_steps = get_option('bundle_builder_steps', array());

    if (empty($bundle_builder_steps)) {
        echo '<p>No steps have been configured yet. Please check the Bundle Builder settings in the admin dashboard.</p>';
        return ob_get_clean();
    }

    ?>
    <div id="bundle-builder">
        <h1 class="main_title">Style Your Own Box</h1>
        <div class="bundle-progress-bar">
            <ul>
                <?php foreach ($bundle_builder_steps as $index => $step) { ?>
                    <li class="step" id="step-indicator-<?php echo $index + 1; ?>" data-step="<?php echo $index + 1; ?>">
                        <span class="step-number"><?php echo $index + 1; ?></span>
                        <span class="step-name"><?php echo esc_html($step['name']); ?></span>
                    </li>
                <?php } ?>
                <li class="step" id="step-indicator-<?php echo count($bundle_builder_steps) + 1; ?>"
                    data-step="<?php echo count($bundle_builder_steps) + 1; ?>">
                    <span class="step-number"><?php echo count($bundle_builder_steps) + 1; ?></span>
                    <span class="step-name">Custom Message</span>
                </li>
                <li class="step" id="step-indicator-<?php echo count($bundle_builder_steps) + 2; ?>"
                    data-step="<?php echo count($bundle_builder_steps) + 2; ?>">
                    <span class="step-number"><?php echo count($bundle_builder_steps) + 2; ?></span>
                    <span class="step-name">Final Preview</span>
                </li>
            </ul>
        </div>

        <!-- Bundle Steps -->
        <?php foreach ($bundle_builder_steps as $index => $step) { ?>
           <div class="bundle-step" id="step-<?php echo $index + 1; ?>"
    style="display: <?php echo $index === 0 ? 'block' : 'none'; ?>;"
    data-mandatory="<?php echo esc_attr($step['mandatory'] ? 'true' : 'false'); ?>"
    data-required="<?php echo ($index < 3) ? 'true' : 'false'; ?>">
    <h3 class="step_head"><?php echo esc_html($step['name']); ?>
        <?php if ($index < 3): ?>
            <span class="required-indicator">*</span>
        <?php endif; ?>
    </h3>
                <div class="filterss">
                    <!-- Search Filter -->
                    <input type="text" class="product-search" placeholder="Search" data-step="<?php echo $index + 1; ?>" />
                    <div class="pg-filtter">
                        <!-- Price Filter Dropdown -->
                        <select class="price-filter" data-step="<?php echo $index + 1; ?>">
                            <option value="all">All Prices</option>
                            <option value="0-1000">Below ₹1000</option>
                            <option value="1000-2000">₹1000 - ₹2000</option>
                            <option value="2000-3000">₹2000 - ₹3000</option>
                            <option value="3000-4000">₹3000 - ₹4000</option>
                            <option value="5000+">Above ₹5000</option>
                        </select>
                    </div>
                </div>
                <!-- Product Cards for the first step -->
                <div class="bundle-container">
                <?php if ($index === 1): // Show category links only in the second step ?>
                    <?php
                    // Fetch categories excluding those with specific keywords
                    $categories = get_terms('product_cat', array('hide_empty' => true, 'cache_results' => false));

                    // Debugging: Log category names and slugs to check values
                    error_log("Category Names: " . print_r(wp_list_pluck($categories, 'name'), true));
                    error_log("Category Slugs: " . print_r(wp_list_pluck($categories, 'slug'), true));

                    if (!empty($categories)): // Check if categories exist
                        // Excluded slugs (exact match)
                        $excluded_slugs = ['new-born', 'new-mom', 'house-warming'];

                        // Excluded keywords (partial match)
                        $excluded_keywords = ['hampers', 'boxes', 'cards', 'congratulations', 'electronics', 'celebration', 'inspirational', 'sale', 'sustainable']; 
                        ?>
                        <!-- Category Filter Links -->
                        <div class="category-filter-wrapper">
                            <button class="category-filter-toggle">Filter by Category</button>
                            <div class="category-links" data-step="<?php echo esc_attr($index + 1); ?>">
                                <ul class="category-list">
                                    <li><a href="#" class="category-link" data-category="all">All Categories</a></li>
                                    <?php
                                    foreach ($categories as $category) {
                                        // Skip categories with zero products
                                        if ($category->count == 0) {
                                            continue;
                                        }

                                        // Skip exact slug matches
                                        if (in_array($category->slug, $excluded_slugs)) {
                                            continue;
                                        }

                                        // Skip categories that contain specific keywords in the name
                                        foreach ($excluded_keywords as $keyword) {
                                            if (stripos($category->name, $keyword) !== false) {
                                                continue 2; // Skip this category
                                            }
                                        }

                                        echo '<li><a href="#" class="category-link" data-category="' . esc_attr($category->term_id) . '">' . esc_html($category->name) . '</a></li>';
                                    }
                                    ?>
                                </ul>
                            </div>
                        </div>
                    <?php endif; // End check for empty categories ?>
                <?php endif; ?>
                    <div class="product-cards" id="product-cards-step-<?php echo $index + 1; ?>">
                        <?php
                        // Get products for the specific category assigned to the step
                        if ($index === 1) { // For the second step, show "box-tagged" products only
                            $products = wc_get_products([
                                'limit' => -1,
                                'status' => 'publish',
                                'tag' => ['not-boxed'], // Replace 'box' with your actual tag slug for box-tagged products
                            ]);
                        } else {
                            $products = wc_get_products([
                                'category' => [$step['category']],
                                'limit' => -1,
                                'status' => 'publish',
                            ]);
                        }
                        if ($products) {
                            foreach ($products as $product) {
                                // Get the product category IDs
                                $product_categories = wp_get_post_terms($product->get_id(), 'product_cat', ['fields' => 'ids']);
                                ?>
                                <div class="product-card" data-product_id="<?php echo esc_attr($product->get_id()); ?>"
                                    data-price="<?php echo esc_attr($product->get_price()); ?>"
                                    data-categories="<?php echo esc_attr(implode(',', $product_categories)); ?>">
                                    <img loading="lazy" src="<?php echo esc_url(wp_get_attachment_url($product->get_image_id())); ?>"
                                        alt="<?php echo esc_attr($product->get_name()); ?>">
                                    <h4><?php echo esc_html($product->get_name()); ?></h4>
                                    <div class="price_btn">
                                        <p class="product-price">
                                            <span class="woocommerce-Price-amount amount">
                                                <?php
                                                if ($product->is_on_sale()) {
                                                    // Strip HTML from formatted price
                                                    echo esc_html(strip_tags(wc_price($product->get_sale_price()))); // Sale price
                                                } else {
                                                    echo esc_html(strip_tags(wc_price($product->get_regular_price()))); // Regular price
                                                }
                                                ?>
                                            </span>
                                        </p>
                                        <!-- Product Selection Button -->
                                        <button class="select-product"
                                            data-selection-type="<?php echo esc_attr($step['selection_type']); ?>"
                                            data-step="<?php echo $index + 1; ?>">
                                            <?php echo esc_html($step['selection_type'] === 'multi' ? 'Add To Box' : 'Add To Box'); ?>
                                        </button>

                                        <!-- Quantity Controls (hidden by default) -->
                                        <div class="quantity controls"style="display: none; ">
                                            <button class="decrease-quantity"
                                                data-product_id="<?php echo esc_attr($product->get_id()); ?>">-</button>
                                            <span class="quantity">1</span>
                                            <button class="increase-quantity"
                                                data-product_id="<?php echo esc_attr($product->get_id()); ?>">+</button>
                                        </div> 
                                    </div>
                                </div>
                                <?php
                            }
                        } else {
                            echo '<p>No products found in this category.</p>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        <?php } ?>

        <!-- Custom Message Step -->
        <div class="bundle-step" id="step-<?php echo count($bundle_builder_steps) + 1; ?>" style="display: none;">
            <h3 class="step_head">Custom Message</h3>
            <label for="custom-message">Enter your custom message:</label>
            <textarea id="custom-message" placeholder="Enter your custom message here..." required></textarea>
        </div>

        <!-- Final Preview Step -->
        <div class="bundle-step" id="step-<?php echo count($bundle_builder_steps) + 2; ?>" style="display: none;">
            <h3 class="step_head">Final Preview</h3>
            <h4 class="mt-20">Your Selected Products:</h4>
            <div class="final-selected-products"></div>
            <div class="total-price-container">
                <span>Total Price: </span><span class="total-price">0</span>
            </div>
            <div class="message">
                <h4>Your Custom Message:</h4>
                <p id="final-custom-message"></p>
            </div>
        </div>

        <!-- Navigation Buttons -->
        <div class="bundle-navigation">
            <div class="total-price-container">
                <div class="final-selected-products final-select"></div>
                <div class="selected-products-container">
                    <!-- Dynamically populated -->
                </div>
            </div>
            <div class="bottom-group">
                <span>Total Price: </span><span class="total-price">0</span>
                <div class="nav_groups">
                    <button id="prev-step" style="display: none;">Previous</button>
                    <button id="next-step">Next</button>
                    <button id="final-add-to-cart" style="display: none;">Checkout</button>
          


                </div>
            </div>
                   
        </div>
           <div id="required-step-warning" style="color: red; margin-top: 10px; display: none;">
    Please complete all required steps by selecting at least one product in each.
</div>
    </div>
    <?php

    return ob_get_clean();
}

// Hook for AJAX call
add_action('wp_ajax_add_bundle_to_cart', 'add_bundle_to_cart');
add_action('wp_ajax_nopriv_add_bundle_to_cart', 'add_bundle_to_cart');

function add_bundle_to_cart() {
    if (isset($_POST['products']) && !empty($_POST['products'])) {
        $products = json_decode(stripslashes($_POST['products']), true);
        $message = isset($_POST['message']) ? sanitize_text_field($_POST['message']) : '';

        // 🔁 Empty existing cart before adding new bundle
        WC()->cart->empty_cart();

        foreach ($products as $product) {
            $product_id = $product['product_id'];
            $quantity = intval($product['quantity']);
            WC()->cart->add_to_cart($product_id, $quantity, 0, array(), array(
    'hide_in_cart' => true // custom flag
));

        }

        if (!empty($message)) {
            WC()->session->set('custom_message', $message);
        }

        wp_send_json_success(['message' => 'Bundle added to cart']);
    } else {
        wp_send_json_error(['message' => 'No products selected']);
    }

    wp_die();
}


// Hook to save the custom message into the order meta during checkout
add_action('woocommerce_checkout_create_order', 'save_custom_message_in_order_meta', 10, 2);
function save_custom_message_in_order_meta($order, $data)
{
    // Retrieve the custom message from the session
    $custom_message = WC()->session->get('custom_message');

    // If a custom message exists, save it to the order metadata
    if (!empty($custom_message)) {
        $order->update_meta_data('custom_message', sanitize_text_field($custom_message));
        // Clear the custom message from the session once it's stored
        WC()->session->__unset('custom_message');
    }
}

add_filter('woocommerce_cart_item_visible', 'bundle_hide_items_on_cart_page', 10, 2);
function bundle_hide_items_on_cart_page($visible, $cart_item) {
    if (is_cart() && isset($cart_item['hide_in_cart']) && $cart_item['hide_in_cart']) {
        return false; // hide from cart page
    }
    return $visible; // show in checkout
}
add_filter('woocommerce_cart_get_cart', 'bundle_filter_hidden_cart_items');
function bundle_filter_hidden_cart_items($cart_items) {
    if (is_cart() || is_checkout()) {
        return $cart_items; // do not interfere with WooCommerce logic
    }

    // For mini carts, popups, etc.
    return array_filter($cart_items, function($item) {
        return empty($item['hide_in_cart']);
    });
}
add_filter('woocommerce_cart_subtotal', 'bundle_hide_subtotal_if_only_hidden', 10, 3);
function bundle_hide_subtotal_if_only_hidden($subtotal, $compound, $cart) {
    $has_visible = false;

    foreach ($cart->get_cart() as $item) {
        if (empty($item['hide_in_cart'])) {
            $has_visible = true;
            break;
        }
    }

    return $has_visible ? $subtotal : '';
}