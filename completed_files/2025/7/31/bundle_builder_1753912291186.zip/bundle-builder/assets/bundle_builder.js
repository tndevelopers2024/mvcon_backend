jQuery(document).ready(function($) {
    var currentStep = 1;
    var totalSteps = $('.bundle-step').length;
    var selectedProducts = [];
    var requiredSteps = [1, 2, 3]; // Define required steps here

    function calculateTotalPrice() {
        var totalPrice = 0;
        selectedProducts.forEach(function(product) {
            totalPrice += parseFloat(product.product_price) * product.quantity;
        });
        return totalPrice.toFixed(2);
    }

    function updateTotalPrice() {
        var totalPrice = calculateTotalPrice();
        $('.total-price').text(totalPrice);
    }

    function updateProductPreview() {
        var previewContainer = $('.final-selected-products');
        previewContainer.empty();

        selectedProducts.forEach(function(product) {
            if (product.quantity <= 0) return;

            var productHTML = `
                <div class="preview-product" data-product_id="${product.product_id}" data-step="${product.step}">
                    <img src="${product.product_image}" alt="${product.product_name}" />
                    <p class="title-product">${product.product_name}</p>
                    <p><i aria-hidden="true" class="fas fa-rupee-sign"></i> ${parseFloat(product.product_price).toFixed(2)} x ${product.quantity}</p>
                    <button class="remove-product" data-product_id="${product.product_id}" data-step="${product.step}">
                        <i aria-hidden="true" class="far fa-times-circle"></i>
                    </button>
                </div>
            `;
            previewContainer.append(productHTML);
        });

        // Check and toggle add-to-cart button in preview update
        if (currentStep === totalSteps) {
            const allStepsComplete = requiredSteps.every(requiredStep =>
                selectedProducts.some(p => p.step == requiredStep && p.quantity > 0)
            );
            $('#final-add-to-cart').toggle(allStepsComplete);
        }
    }

    function handleProductSelection(product_id, product_name, product_price, selectionType, $button) {
        var product_image = $button.closest('.product-card').find('img').attr('src');
        var step = $button.data('step');
        var $quantityControls = $button.closest('.price_btn').find('.quantity.controls');

        if (selectionType === 'single') {
            selectedProducts = selectedProducts.filter(p => p.step !== step);
        }

        var existingProductIndex = selectedProducts.findIndex(product => product.product_id === product_id);

        if (existingProductIndex === -1) {
            selectedProducts.push({
                product_id: product_id,
                product_name: product_name,
                product_price: product_price,
                product_image: product_image,
                step: step,
                quantity: 1
            });
        } else {
            selectedProducts[existingProductIndex].quantity++;
        }

        $button.hide();
        $quantityControls.show().find('.quantity').text(
            selectedProducts.find(p => p.product_id === product_id).quantity
        );

        updateTotalPrice();
        updateProductPreview();
    }

    $('.select-product').on('click', function() {
        var $button = $(this);
        var product_id = $(this).closest('.product-card').data('product_id');
        var product_name = $(this).closest('.product-card').find('h4').text();
        var product_price = parseFloat($(this).closest('.product-card').data('price'));
        var selectionType = $button.data('selection-type');
        var step = $button.data('step');

        handleProductSelection(product_id, product_name, product_price, selectionType, $button);

        if (selectionType === 'single' && currentStep < totalSteps) {
            currentStep++;
            showStep(currentStep);
        }
    });

    function validateStep(step) {
        if (requiredSteps.includes(step)) {
            var hasSelectedProduct = selectedProducts.some(product =>
                product.step === step && product.quantity > 0
            );
            if (!hasSelectedProduct) {
                alert('Please select at least one product in this step before proceeding.');
                return false;
            }
        }
        return true;
    }

    function updateProgressBar(step) {
        $('.bundle-progress-bar .step').each(function() {
            var stepNumber = $(this).data('step');
            if (stepNumber < step) {
                $(this).removeClass('active').addClass('completed');
            } else if (stepNumber === step) {
                $(this).removeClass('completed').addClass('active');
            } else {
                $(this).removeClass('active completed');
            }
        });
    }

    function showStep(step) {
    $('.bundle-step').removeClass('active').hide();
    $('#step-' + step).addClass('active').fadeIn();
    document.getElementById('step-' + step).scrollIntoView({ behavior: 'smooth', block: 'start' });

    $('#prev-step').toggle(step > 1);
    $('#next-step').toggle(step < totalSteps);
    updateProgressBar(step);

    if (step === totalSteps) {
        $('#final-custom-message').text($('#custom-message').val());
        updateProductPreview();

        const allStepsComplete = requiredSteps.every(requiredStep =>
            selectedProducts.some(p => p.step == requiredStep && p.quantity > 0)
        );

        $('#final-add-to-cart').toggle(allStepsComplete);
        $('#required-step-warning').toggle(!allStepsComplete); // 👈 Show message if not complete
    } else {
        $('#final-add-to-cart').hide();
        $('#required-step-warning').hide(); // hide warning when not on last step
    }
}

    $('#next-step').on('click', function() {
        if (!validateStep(currentStep)) return;

        if (currentStep < totalSteps) {
            currentStep++;
            showStep(currentStep);
        }
    });

    $('#prev-step').on('click', function() {
        if (currentStep > 1) {
            currentStep--;
            showStep(currentStep);
        }
    });

    $(document).on('click', '.remove-product', function() {
        var product_id = $(this).data('product_id');
        var step = $(this).data('step');
        var productIndex = selectedProducts.findIndex(p => p.product_id === product_id);
        if (productIndex !== -1) {
            selectedProducts.splice(productIndex, 1);

            $('#step-' + step + ' .product-card[data-product_id="' + product_id + '"]')
                .find('.select-product').show().end()
                .find('.quantity.controls').hide().find('.quantity').text('1');

            if (requiredSteps.includes(step)) {
                currentStep = step;
                showStep(currentStep);
            }

            updateProductPreview();
            updateTotalPrice();
        }
    });

    $(document).on('click', '.increase-quantity', function() {
        var product_id = $(this).data('product_id');
        var product = selectedProducts.find(p => p.product_id === product_id);

        if (product) {
            product.quantity++;
            $(this).siblings('.quantity').text(product.quantity);
            updateProductPreview();
            updateTotalPrice();
        }
    });

    $(document).on('click', '.decrease-quantity', function() {
        var product_id = $(this).data('product_id');
        var product = selectedProducts.find(p => p.product_id === product_id);

        if (product && product.quantity > 1) {
            product.quantity--;
            $(this).siblings('.quantity').text(product.quantity);
            updateProductPreview();
            updateTotalPrice();
        } else if (product && product.quantity === 1) {
            $(this).closest('.quantity.controls').hide();
            $(this).closest('.price_btn').find('.select-product').show();

            var step = $('#step-' + currentStep).data('step');
            var productIndex = selectedProducts.findIndex(p => p.product_id === product_id);
            if (productIndex !== -1) {
                selectedProducts.splice(productIndex, 1);

                if (requiredSteps.includes(step)) {
                    currentStep = step;
                    showStep(currentStep);
                }

                updateProductPreview();
                updateTotalPrice();
            }
        }
    });

$('#final-add-to-cart').on('click', function() {
    var allStepsComplete = requiredSteps.every(step =>
        selectedProducts.some(p => p.step == step && p.quantity > 0)
    );

    if (!allStepsComplete) {
        alert('Please complete all required steps before adding to cart.');
        var firstIncomplete = requiredSteps.find(step =>
            !selectedProducts.some(p => p.step == step && p.quantity > 0)
        );
        if (firstIncomplete) {
            currentStep = firstIncomplete;
            showStep(currentStep);
        }
        return;
    }

    var customMessage = $('#custom-message').val();

    $.ajax({
        url: bundle_builder.ajax_url,
        method: 'POST',
        data: {
            action: 'add_bundle_to_cart',
            products: JSON.stringify(selectedProducts),
            message: customMessage
        },
        success: function(response) {
            if (response.success) {
                // 🔁 redirect directly to checkout
                window.location.href = '/checkout/';
            } else {
                alert('Error: ' + response.data);
            }
        },
        error: function() {
            alert('An error occurred while adding products to the cart.');
        }
    });
});


    $('.product-search').on('input', function() {
        var searchTerm = $(this).val().toLowerCase();
        var step = $(this).data('step');

        $('#product-cards-step-' + step + ' .product-card').each(function() {
            var productName = $(this).find('h4').text().toLowerCase();
            $(this).toggle(productName.includes(searchTerm));
        });
    });

    $('.price-filter').on('change', function() {
        var priceRange = $(this).val();
        var step = $(this).data('step');

        $('#product-cards-step-' + step + ' .product-card').each(function() {
            var productPrice = parseFloat($(this).data('price'));
            switch (priceRange) {
                case '0-1000': $(this).toggle(productPrice < 1000); break;
                case '1000-2000': $(this).toggle(productPrice >= 1000 && productPrice < 2000); break;
                case '2000-3000': $(this).toggle(productPrice >= 2000 && productPrice < 3000); break;
                case '3000-4000': $(this).toggle(productPrice >= 3000 && productPrice < 4000); break;
                case '5000+': $(this).toggle(productPrice >= 5000); break;
                default: $(this).show();
            }
        });
    });

    $('.category-link').on('click', function(e) {
        e.preventDefault();
        var selectedCategory = $(this).data('category');
        var step = $(this).closest('.category-links').data('step');

        $(this).closest('.category-list').find('.category-link').removeClass('active');
        $(this).addClass('active');

        $('#product-cards-step-' + step + ' .product-card').each(function() {
            var productCategories = $(this).data('categories').toString().split(',');
            $(this).toggle(selectedCategory === 'all' || productCategories.includes(String(selectedCategory)));
        });
    });

    // Start with first step
    showStep(currentStep);
});